package com.example.assn2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView create, start, resume, restart;
    Button op;
    static int cr=0, st=0, re=0, rt=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        create=findViewById(R.id.textView2);
        start=findViewById(R.id.textView3);
        resume=findViewById(R.id.textView4);
        restart=findViewById(R.id.textView5);
        op=findViewById(R.id.button);
        cr++;
        create.setText("OnCreate() is called:"+ cr);
        start.setText("OnStart() is called:"+ st);
        resume.setText("OnResume() is called:"+ re);
        restart.setText("OnRestart() is called:"+ rt);
        Log.i("key","onCreate is called:");
        op.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,MainActivity2.class);
                startActivity(i);
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        rt++;
        restart.setText("OnRestart() is called:"+ rt);
        Log.i("key","onRestart is called:");
    }

    @Override
    protected void onStart() {
        super.onStart();
        st++;
        start.setText("OnStart() is called:"+ st);
        Log.i("key","onStart is called:");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("key","onDestroy is called:");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("key","onPause is called:");
    }

    @Override
    protected void onResume() {
        super.onResume();
        re++;
        resume.setText("OnResume() is called:"+ re);
        Log.i("key","onResume is called:");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("key","onStop is called:");
    }
}